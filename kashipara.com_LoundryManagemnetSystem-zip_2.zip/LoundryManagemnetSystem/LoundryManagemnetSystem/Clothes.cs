﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LoundryManagemnetSystem
{
    public partial class Clothes : Form
    {
        public Clothes()
        {
            InitializeComponent();
        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            label15.Text = (comboBox1.SelectedIndex * int.Parse(label12.Text)).ToString();


        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            label16.Text = (comboBox2.SelectedIndex * int.Parse(label13.Text)).ToString();

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            label17.Text = (comboBox3.SelectedIndex * int.Parse(label14.Text)).ToString();

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            label18.Text = (int.Parse(label15.Text) + int.Parse(label16.Text) + int.Parse(label17.Text)).ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            comboBox1.Text = "0";
            comboBox2.Text = "0";
            comboBox3.Text = "0";
            label18.Text = "00";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            textBox2.Text = "";
            SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\N\Documents\Visual Studio 2010\Projects\LoundryManagemnetSystem\LoundryManagemnetSystem\Database1.mdf;Integrated Security=True;User Instance=True");

            con.Open();
            if (textBox1.Text != "")
            {
                try
                {
                    string getCust = "select name from customer where id=" + Convert.ToInt32(textBox1.Text) + " ;";

                    SqlCommand cmd = new SqlCommand(getCust, con);
                    SqlDataReader dr;
                    dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        textBox2.Text = dr.GetValue(0).ToString();
                    }
                    else
                    {
                        MessageBox.Show("Sorry '" + textBox1.Text + "' This Registration Id is Invalide, Please Insert Correct Id");
                        textBox1.Text = "";
                        textBox2.Text = "";
                    }
                }
                catch (SqlException excep)
                {
                    MessageBox.Show(excep.Message);
                }
                con.Close();
            }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\N\Documents\Visual Studio 2010\Projects\LoundryManagemnetSystem\LoundryManagemnetSystem\Database1.mdf;Integrated Security=True;User Instance=True");
            con.Open();
            try
            {
                string str = " INSERT INTO bill VALUES('" + textBox1.Text + "','" + textBox2.Text + "','" + label18.Text + "'); ";

                SqlCommand cmd = new SqlCommand(str, con);
                cmd.ExecuteNonQuery();

                //-------------------------------------------//

                string str1 = "select max(id) from bill;";

                SqlCommand cmd1 = new SqlCommand(str1, con);
                SqlDataReader dr = cmd1.ExecuteReader();
                if (dr.Read())
                {
                    MessageBox.Show("Bill Deatils Inserted Successfully..");

                }
                this.Close();
            }
            catch (SqlException excep)
            {
                MessageBox.Show(excep.Message);
            }
            con.Close();
        }
    }
}

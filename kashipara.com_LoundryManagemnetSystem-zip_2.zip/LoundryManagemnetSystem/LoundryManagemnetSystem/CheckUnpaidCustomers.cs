﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LoundryManagemnetSystem
{
    public partial class CheckUnpaidCustomers : Form
    {
        public CheckUnpaidCustomers()
        {
            InitializeComponent();
        }

        private void CheckUnpaidCustomers_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'database1DataSet.bill2' table. You can move, or remove it, as needed.
            this.bill2TableAdapter.Fill(this.database1DataSet.bill2);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\N\Documents\Visual Studio 2010\Projects\LoundryManagemnetSystem\LoundryManagemnetSystem\Database1.mdf;Integrated Security=True;User Instance=True"))
            {
                string str = "SELECT * FROM bill2 WHERE unpaid > 0";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = new BindingSource(dt, null);
            }
        }
    }
}

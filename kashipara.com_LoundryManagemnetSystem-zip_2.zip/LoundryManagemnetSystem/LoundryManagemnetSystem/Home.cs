﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LoundryManagemnetSystem
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void newCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewCustomer obj1 = new NewCustomer();
            obj1.ShowDialog();
        }

        private void clothesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clothes obj2=new Clothes();
            obj2.ShowDialog();
        }

        private void billToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Bill obj3 = new Bill();
            obj3.ShowDialog();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CheckUnpaidCustomers obj4 = new CheckUnpaidCustomers();
            obj4.ShowDialog();
        }

        private void closeToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
